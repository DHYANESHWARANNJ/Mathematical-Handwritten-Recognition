# -*- coding: utf-8 -*-

import os, shutil
from os import walk
from flask import Flask, render_template, request, redirect, url_for, current_app, flash
from werkzeug.utils import secure_filename
import jinja2
import shutil
import sys
from os.path import dirname, abspath
#print(sys.path)
sys.path.append("C:\\Users\\NEW\\OneDrive\\Desktop\\S8 Project\\final\\final")
import main as ms

 
# ALLOWED_EXTENSIONS = {'png', 'jpg', 'jpeg'}
app = Flask(__name__)

@app.route('/', methods=['GET'])
def index():
    input_path =  PAR_DIR_PATH + "\\uploads\\"
    print("input_path",input_path)
    shutil.rmtree(input_path)
    os.mkdir(input_path)
    return render_template('index.html')


PAR_DIR_PATH = dirname(abspath(__file__))
print("PAR_DIR_PATH -->",PAR_DIR_PATH)
cwd = os.getcwd()
print(cwd)
app.config['UPLOAD_FOLDER'] = PAR_DIR_PATH + '\\uploads\\'
# /Users/stlp/Desktop/index/uploads/
# need to  be modified on different machines


@app.route('/')
def upload_f():
   return render_template('index.html')

@app.route('/uploader', methods=['GET', 'POST'])  # uploader
def upload_file():
   if request.method == 'POST':
      f = request.files['file']
      print("file_d",f)
      print("f.filename",f.filename)
      f.save(os.path.join(app.config['UPLOAD_FOLDER'],secure_filename(f.filename)))

      return render_template('wait.html')

RESULT_FOLDER = PAR_DIR_PATH + "\\results\\" # os.path.join('static', 'people_photo')
app.config['RESULT_FOLDER'] = RESULT_FOLDER


@app.route('/result', methods=['GET', 'POST'])
def show_result():
    res_calculation_path =os.path.join(RESULT_FOLDER ,"calculationResult.txt")
    h = open(res_calculation_path, 'r')
  
    # Reading from the file 
    content = h.readlines() 

    # Varaible for storing the sum 
    mynum = "No result available"

    # Iterating through the content 
    # Of the file 
    for line in content: 
        mynum = line # int(line) 

    mathresult_path =os.path.join(RESULT_FOLDER ,"MathJaxResult.txt")
    f = open(mathresult_path, 'r') 
  
    # Reading from the file 
    cont = f.readlines() 

    # Varaible for storing the sum 
    mylatex = "No latex output available"

    # Iterating through the content 
    # Of the file 
    for line in cont: 
        mylatex = line # int(line) 

    return render_template("result.html", user_number = mynum, user_latex = mylatex)


@app.route('/reset')
def remove():
    output_path =  PAR_DIR_PATH + "//results//" 
    prefix = os.path.abspath(output_path) 
    file_list = [os.path.join(prefix, f) for f in os.listdir(prefix) if f.endswith('.txt')]
    
    input_path =  PAR_DIR_PATH + "//uploads//" 
  

    try:
 
        shutil.rmtree(input_path)
        os.mkdir(input_path) 

        for file in file_list:
          os.remove(file)
        # return filename
        return render_template("index.html")
    except Exception as e:
        return f"Error in deleting files: {e}"


@app.route("/trigger-python", methods=['GET', 'POST'])
def call_python():
    print("Successful line print")
    ms.my_func()
    return 'OK'

@app.route('/error')
def render_error():
   return render_template('error.html')

if __name__ == '__main__':
    app.run(debug=True)
